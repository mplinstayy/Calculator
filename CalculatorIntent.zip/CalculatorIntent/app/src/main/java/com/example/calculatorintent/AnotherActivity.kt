package com.example.calculatorintent

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AnotherActivity:AppCompatActivity() {
    private lateinit var tw: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_another)

        val data = intent.getStringExtra("data")

        tw = findViewById(R.id.textView3)
        tw.text = "$data"
    }
}