package com.example.calculatorintent

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    private lateinit var btnPlus:Button
    private lateinit var btnMinus:Button
    private lateinit var btnMultiply:Button
    private lateinit var btnDivide:Button
    private lateinit var btnRoot:Button
    private lateinit var editText: EditText

    private lateinit var firstNum:EditText
    private lateinit var secondNum:EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnPlus = findViewById(R.id.buttonPlus)
        btnMinus = findViewById(R.id.buttonMinus)
        btnMultiply = findViewById(R.id.buttonMultiply)
        btnDivide = findViewById(R.id.buttonDivide)
        btnRoot = findViewById(R.id.buttonRoot)

        firstNum = findViewById(R.id.editTextNumber)
        secondNum = findViewById(R.id.editTextNumber2)

        val calc:Calculate

        btnPlus.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()

            val add = calc.add(fNumFloat, sNumFloat).toString()
            val putExtra = intent.putExtra("data", add)
        }

        btnMinus.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()
        }
        btnMultiply.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()
        }
        btnDivide.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()
        }
        btnDivide.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()
        }
        btnRoot.setOnClickListener {
            val intent = Intent(this, AnotherActivity::class.java)
            val fNumFloat = firstNum.toString().toFloat()
            val sNumFloat = secondNum.toString().toFloat()
        }
    }
}